// index.js

// Carrega as variáveis de ambiente do arquivo .env
require('dotenv').config();

// --- IMPORTAÇÕES DAS BIBLIOTECAS ---
const express = require('express'); // << A CORREÇÃO ESTÁ AQUI! Era 'expess'
const mysql = require('mysql2');
const bcrypt = require('bcrypt');
const session = require('express-session');

// --- CONFIGURAÇÃO INICIAL DO APP ---
const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// --- CONFIGURAÇÃO DA SESSÃO ---
app.use(session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: false,
        maxAge: 3600000
    }
}));

// --- CONEXÃO COM O BANCO DE DADOS ---
const connection = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
});

connection.connect(error => {
  if (error) {
    console.error('Erro ao conectar com o banco de dados:', error);
    return;
  }
  console.log('Conexão com o banco de dados MySQL bem-sucedida!');
});

// --- ROTAS DE AUTENTICAÇÃO ---
app.get('/', (req, res) => res.redirect('/login'));
app.get('/login', (req, res) => res.render('login'));
app.post('/login', (req, res) => {
    const { email, senha } = req.body;
    const sql = 'SELECT * FROM usuarios WHERE email = ?';
    connection.query(sql, [email], async (error, results) => {
        if (error) { return res.redirect('/login'); }
        if (results.length === 0) { return res.redirect('/login'); }
        const usuario = results[0];
        try {
            const senhaCorreta = await bcrypt.compare(senha, usuario.senha);
            if (senhaCorreta) {
                req.session.user = { id: usuario.id, nome: usuario.nome, email: usuario.email, tipo: usuario.tipo_usuario };
                return res.redirect('/dashboard');
            } else {
                return res.redirect('/login');
            }
        } catch (err) {
            console.error('Erro ao comparar senhas:', err);
            return res.redirect('/login');
        }
    });
});
app.get('/cadastro', (req, res) => res.render('cadastro'));
app.post('/cadastro', async (req, res) => {
    const { nome, email, senha, nome_ecommerce } = req.body;
    try {
        const hashDaSenha = await bcrypt.hash(senha, 10);
        const novoUsuario = { nome, email, senha: hashDaSenha, nome_ecommerce, tipo_usuario: 'cliente' };
        const sql = 'INSERT INTO usuarios SET ?';
        connection.query(sql, novoUsuario, (error, results) => {
            if (error) { return res.status(500).send('Erro ao criar a conta.'); }
            res.redirect('/login');
        });
    } catch(err) {
        console.error('Erro no hash/cadastro:', err);
        return res.status(500).send('Erro interno.');
    }
});

// --- ROTAS PROTEGIDAS (SÓ ACESSÍVEIS APÓS LOGIN) ---

app.get('/dashboard', (req, res) => {
    if (req.session.user) {
        res.render('dashboard_cliente', { usuario: req.session.user });
    } else {
        res.redirect('/login');
    }
});

app.get('/perfil', (req, res) => {
    if (!req.session.user) { return res.redirect('/login'); }
    const usuarioId = req.session.user.id;
    const sql = 'SELECT nome, email, nome_ecommerce, reputacao, data_criacao, numero_telefone FROM usuarios WHERE id = ?';
    connection.query(sql, [usuarioId], (error, results) => {
        if (error) { return res.redirect('/dashboard'); }
        if (results.length > 0) {
            res.render('perfil', { perfil: results[0] });
        } else {
            res.redirect('/login');
        }
    });
});

app.get('/api/dados-vendas', (req, res) => {
    if (!req.session.user) {
        return res.status(401).json({ error: 'Não autorizado' });
    }
    const usuarioId = req.session.user.id;
    const sql = `
        SELECT 
            DATE_FORMAT(data_venda, '%d/%m/%Y') as dia, 
            SUM(valor_venda) as total_vendido
        FROM dados_ecommerce 
        WHERE usuario_id = ? 
        GROUP BY dia 
        ORDER BY data_venda ASC;
    `;
    connection.query(sql, [usuarioId], (error, results) => {
        if (error) {
            console.error("Erro ao buscar dados para o gráfico:", error);
            return res.status(500).json({ error: 'Erro interno do servidor' });
        }
        const labels = results.map(item => item.dia);
        const data = results.map(item => item.total_vendido);
        res.json({ labels, data });
    });
});

app.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) { return res.redirect('/'); }
        res.clearCookie('connect.sid');
        res.redirect('/login');
    });
});

// --- INICIALIZAÇÃO DO SERVIDOR ---
app.listen(PORT, () => {
  console.log(`Servidor ByDash rodando em http://localhost:${PORT}`);
});