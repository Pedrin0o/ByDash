-- Cria o banco de dados do nosso projeto
CREATE DATABASE bydash_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Seleciona o banco de dados para usar
USE bydash_db;

-- Tabela para armazenar todos os usuários (clientes e administradores)
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL, -- Armazenará a senha criptografada (hash)
    tipo_usuario ENUM('cliente', 'adm') NOT NULL DEFAULT 'cliente',
    numero_telefone VARCHAR(20),
    nome_ecommerce VARCHAR(255),
    logo_ecommerce_url VARCHAR(255), -- Caminho para a imagem do logo
    reputacao INT DEFAULT 0,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela para armazenar os feedbacks enviados pelos clientes
CREATE TABLE feedbacks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    titulo VARCHAR(255) NOT NULL,
    mensagem TEXT NOT NULL,
    status ENUM('aberto', 'em_analise', 'resolvido') DEFAULT 'aberto',
    data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Inserir um usuário administrador para testes iniciais
-- A senha 'admin123' será criptografada pelo bcrypt no código antes de inserir
-- Por enquanto, vamos deixar a tabela vazia para criarmos o registro via código

-- Garante que estamos usando o banco de dados correto
USE bydash_db;

-- Limpa a tabela de dados antigos para evitar duplicatas, caso você já tenha inserido os do usuário 1
DELETE FROM dados_ecommerce;

-- Insere o primeiro conjunto de dados de EXEMPLO para o usuário com ID = 1
INSERT INTO dados_ecommerce (usuario_id, data_venda, valor_venda, produto_vendido) VALUES
(2, '2025-10-01 10:30:00', 150.75, 'Produto A'),
(2, '2025-10-01 14:00:00', 89.90, 'Produto B'),
(2, '2025-10-02 09:15:00', 230.00, 'Produto C'),
(2, '2025-10-02 18:45:00', 45.50, 'Produto A'),
(2, '2025-10-03 11:00:00', 310.20, 'Produto D'),
(2, '2025-10-04 16:20:00', 199.99, 'Produto B'),
(2, '2025-10-04 20:00:00', 75.00, 'Produto E'),
(2, '2025-10-05 12:00:00', 450.60, 'Produto C'),
(2, '2025-10-06 10:00:00', 220.00, 'Produto F'),
(2, '2025-10-07 13:30:00', 180.40, 'Produto A');

-- Insere o segundo conjunto de dados de EXEMPLO, também para o usuário com ID = 1 (A CORREÇÃO ESTÁ AQUI)
INSERT INTO dados_ecommerce (usuario_id, data_venda, valor_venda, produto_vendido) VALUES
(2, '2025-10-05 08:00:00', 55.00, 'Produto X'),
(2, '2025-10-06 15:00:00', 125.80, 'Produto Y');

-- Garante que estamos usando o banco de dados correto
USE bydash_db;

-- Altera o tipo do usuário com ID = 1 para 'adm'
UPDATE usuarios 
SET tipo_usuario = 'adm' 
WHERE id = 1;

-- Garante que estamos usando o banco de dados correto
USE bydash_db;

-- Adiciona a nova coluna para rastrear a data da última atualização da reputação
ALTER TABLE usuarios
ADD COLUMN ultima_atualizacao_reputacao DATE DEFAULT NULL;

USE bydash_db;

-- Insere uma venda com a data de ONTEM para o usuário com ID = 2
-- A função CURDATE() - 1 pega a data de ontem automaticamente
INSERT INTO dados_ecommerce (usuario_id, data_venda, valor_venda, produto_vendido)
VALUES (2, CONCAT(CURDATE() - INTERVAL 1 DAY, ' 14:00:00'), 100.00, 'Produto Teste Reputação');

-- Garante que estamos usando o banco de dados correto
USE bydash_db;

-- Adiciona as colunas para a resposta do administrador
ALTER TABLE feedbacks
ADD COLUMN resposta_adm TEXT DEFAULT NULL,
ADD COLUMN data_resposta DATETIME DEFAULT NULL;