// index.js

// Carrega as variáveis de ambiente do arquivo .env
require('dotenv').config();

// --- IMPORTAÇÕES DAS BIBLIOTECAS ---
const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
const session = require('express-session');
const PDFDocument = require('pdfkit'); // Biblioteca para gerar PDF
const app = express();
const PORT = process.env.PORT || 3000;
app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(session({ secret: process.env.SESSION_SECRET, resave: false, saveUninitialized: false, cookie: { secure: false, maxAge: 3600000 } }));

// A conexão agora usa createPool para melhor performance
const connection = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});


// --- Nova Função para Atualizar a Reputação ---
async function atualizarReputacaoCliente(usuarioId) {
    try {
        const [usuarios] = await connection.execute("SELECT reputacao, ultima_atualizacao_reputacao FROM usuarios WHERE id = ?", [usuarioId]);
        if (usuarios.length === 0) return;
        const usuario = usuarios[0];
        const hoje = new Date();
        hoje.setHours(0, 0, 0, 0);
        const ultimaAtualizacao = usuario.ultima_atualizacao_reputacao ? new Date(usuario.ultima_atualizacao_reputacao) : null;
        if (ultimaAtualizacao && ultimaAtualizacao.getTime() === hoje.getTime()) {
            return;
        }
        const ontem = new Date(hoje);
        ontem.setDate(ontem.getDate() - 1);
        const dataOntemFormatada = ontem.toISOString().slice(0, 10);
        const [vendas] = await connection.execute("SELECT COUNT(id) AS total_vendas FROM dados_ecommerce WHERE usuario_id = ? AND DATE(data_venda) = ?", [usuarioId, dataOntemFormatada]);
        if (vendas[0].total_vendas > 0) {
            const novaReputacao = usuario.reputacao + 1;
            await connection.execute("UPDATE usuarios SET reputacao = ?, ultima_atualizacao_reputacao = ? WHERE id = ?", [novaReputacao, hoje, usuarioId]);
            console.log(`Reputação do usuário ${usuarioId} aumentada para ${novaReputacao}!`);
        } else {
            await connection.execute("UPDATE usuarios SET ultima_atualizacao_reputacao = ? WHERE id = ?", [hoje, usuarioId]);
        }
    } catch (error) { console.error("Erro ao atualizar a reputação:", error); }
}


// --- ROTAS DE AUTENTICAÇÃO ---
app.get('/', (req, res) => res.redirect('/login'));
app.get('/login', (req, res) => res.render('login'));
app.post('/login', async (req, res) => {
    const { email, senha } = req.body;
    const sql = 'SELECT * FROM usuarios WHERE email = ?';
    try {
        const [results] = await connection.execute(sql, [email]);
        if (results.length === 0) { return res.redirect('/login'); }
        const usuario = results[0];
        const senhaCorreta = await bcrypt.compare(senha, usuario.senha);
        if (senhaCorreta) {
            req.session.user = { id: usuario.id, nome: usuario.nome, email: usuario.email, tipo: usuario.tipo_usuario };
            if (usuario.tipo_usuario === 'adm') {
                return res.redirect('/admin/dashboard');
            } else {
                await atualizarReputacaoCliente(usuario.id);
                return res.redirect('/dashboard');
            }
        } else { return res.redirect('/login'); }
    } catch(err) { console.error("Erro no login:", err); return res.redirect('/login'); }
});
app.get('/cadastro', (req, res) => { res.render('cadastro'); });
app.post('/cadastro', async (req, res) => { const { nome, email, senha, nome_ecommerce } = req.body; const hashDaSenha = await bcrypt.hash(senha, 10); const novoUsuario = { nome, email, senha: hashDaSenha, nome_ecommerce, tipo_usuario: 'cliente' }; const sql = 'INSERT INTO usuarios SET ?'; try { await connection.execute(sql, [novoUsuario]); res.redirect('/login'); } catch (error) { res.status(500).send('Erro ao criar a conta.'); } });

// --- Middlewares de Proteção ---
function isClient(req, res, next) { if (req.session.user && req.session.user.tipo === 'cliente') { return next(); } res.redirect('/login'); }
function isAdmin(req, res, next) { if (req.session.user && req.session.user.tipo === 'adm') { return next(); } res.redirect('/login'); }

// --- ROTAS PROTEGIDAS DO CLIENTE ---
app.get('/dashboard', isClient, (req, res) => { res.render('dashboard_cliente', { usuario: req.session.user }); });
app.get('/perfil', isClient, async (req, res) => { const usuarioId = req.session.user.id; const sql = 'SELECT nome, email, nome_ecommerce, reputacao, data_criacao, numero_telefone FROM usuarios WHERE id = ?'; try { const [results] = await connection.execute(sql, [usuarioId]); if (results.length === 0) { return res.redirect('/login'); } res.render('perfil', { perfil: results[0] }); } catch (error) { res.redirect('/login'); } });
app.get('/perfil/editar', isClient, async (req, res) => { const usuarioId = req.session.user.id; const sql = "SELECT nome, email, nome_ecommerce, numero_telefone FROM usuarios WHERE id = ?"; try { const [results] = await connection.execute(sql, [usuarioId]); if (results.length === 0) { return res.redirect('/perfil'); } res.render('perfil_editar', { usuario: results[0] }); } catch (error) { console.error("Erro ao buscar dados para editar perfil:", error); res.redirect('/perfil'); } });
app.post('/perfil/editar', isClient, async (req, res) => { const usuarioId = req.session.user.id; const { nome, nome_ecommerce, numero_telefone } = req.body; const sql = "UPDATE usuarios SET nome = ?, nome_ecommerce = ?, numero_telefone = ? WHERE id = ?"; try { await connection.execute(sql, [nome, nome_ecommerce, numero_telefone, usuarioId]); req.session.user.nome = nome; res.redirect('/perfil'); } catch (error) { console.error("Erro ao atualizar perfil:", error); res.redirect('/perfil/editar'); } });
app.get('/perfil/certificado', isClient, async (req, res) => { try { const usuarioId = req.session.user.id; const sql = "SELECT nome, nome_ecommerce, reputacao FROM usuarios WHERE id = ?"; const [results] = await connection.execute(sql, [usuarioId]); if (results.length === 0) { return res.redirect('/perfil'); } const usuario = results[0]; const doc = new PDFDocument({ size: 'A4', layout: 'landscape', margin: 50 }); const filename = `Certificado-ByDash-${usuario.nome.replace(/\s+/g, '-')}.pdf`; res.setHeader('Content-Type', 'application/pdf'); res.setHeader('Content-Disposition', `attachment; filename="${filename}"`); doc.pipe(res); doc.rect(20, 20, doc.page.width - 40, doc.page.height - 40).stroke(); doc.fontSize(32).font('Helvetica-Bold').text('Certificado de Reputação ByDash', { align: 'center' }); doc.moveDown(2); doc.fontSize(18).font('Helvetica').text('Certificamos que o e-commerce', { align: 'center' }); doc.moveDown(1); doc.fontSize(28).font('Helvetica-Bold').fillColor('#e94560').text(usuario.nome_ecommerce, { align: 'center' }); doc.moveDown(1); doc.fontSize(16).fillColor('black').font('Helvetica').text(`sob a gestão de ${usuario.nome}, alcançou a reputação de:`, { align: 'center' }); doc.moveDown(1.5); doc.fontSize(72).font('Helvetica-Bold').fillColor('#0f3460').text(usuario.reputacao, { align: 'center' }); doc.fontSize(24).fillColor('#0f3460').text('Pontos', { align: 'center' }); doc.moveDown(2); const hoje = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' }); doc.fontSize(12).fillColor('black').font('Helvetica').text(`Emitido em: ${hoje}`, { align: 'center' }); doc.end(); } catch (error) { console.error("Erro ao gerar certificado:", error); res.redirect('/perfil'); } });
app.get('/api/dados-vendas', isClient, async (req, res) => { const usuarioId = req.session.user.id; const sql = `SELECT DATE_FORMAT(data_venda, '%d/%m/%Y') as dia, SUM(valor_venda) as total_vendido FROM dados_ecommerce WHERE usuario_id = ? GROUP BY dia ORDER BY data_venda ASC;`; try { const [results] = await connection.execute(sql, [usuarioId]); const labels = results.map(item => item.dia); const data = results.map(item => item.total_vendido); res.json({ labels, data }); } catch (error) { res.status(500).json({ error: 'Erro interno no servidor' }); } });
app.get('/api/produtos-mais-vendidos', isClient, async (req, res) => { const usuarioId = req.session.user.id; const sql = `SELECT produto_vendido, COUNT(produto_vendido) as quantidade FROM dados_ecommerce WHERE usuario_id = ? GROUP BY produto_vendido ORDER BY quantidade DESC;`; try { const [results] = await connection.execute(sql, [usuarioId]); const labels = results.map(item => item.produto_vendido); const data = results.map(item => item.quantidade); res.json({ labels, data }); } catch (error) { res.status(500).json({ error: 'Erro interno no servidor' }); } });
app.get('/feedback', isClient, (req, res) => { res.render('feedback', { usuario: req.session.user }); });
app.post('/feedback', isClient, async (req, res) => { const { titulo, mensagem } = req.body; const usuarioId = req.session.user.id; const sql = "INSERT INTO feedbacks (usuario_id, titulo, mensagem) VALUES (?, ?, ?)"; try { await connection.execute(sql, [usuarioId, titulo, mensagem]); res.redirect('/dashboard'); } catch (error) { res.redirect('/feedback'); } });

// --- ROTAS PROTEGIDAS DO ADMINISTRADOR ---
app.get('/admin/dashboard', isAdmin, async (req, res) => { const sql = "SELECT id, nome, email, nome_ecommerce, reputacao, DATE_FORMAT(data_criacao, '%d/%m/%Y') AS data_formatada FROM usuarios WHERE tipo_usuario = 'cliente' ORDER BY data_criacao DESC"; try { const [clientes] = await connection.execute(sql); res.render('dashboard_adm', { admin: req.session.user, listaClientes: clientes }); } catch (error) { res.render('dashboard_adm', { admin: req.session.user, listaClientes: [] }); } });
app.get('/admin/cliente/:id', isAdmin, async (req, res) => { const clienteId = req.params.id; const sql = "SELECT id, nome, nome_ecommerce FROM usuarios WHERE id = ? AND tipo_usuario = 'cliente'"; try { const [results] = await connection.execute(sql, [clienteId]); if (results.length === 0) { return res.redirect('/admin/dashboard'); } res.render('dashboard_cliente_view', { admin: req.session.user, cliente: results[0] }); } catch (error) { res.redirect('/admin/dashboard'); } });
app.get('/admin/feedbacks', isAdmin, async (req, res) => { const sql = `SELECT f.id, f.titulo, f.status, DATE_FORMAT(f.data_envio, '%d/%m/%Y %H:%i') AS data_formatada, u.nome AS nome_cliente FROM feedbacks AS f LEFT JOIN usuarios AS u ON f.usuario_id = u.id ORDER BY f.data_envio DESC;`; try { const [feedbacks] = await connection.execute(sql); res.render('feedbacks_adm', { admin: req.session.user, listaFeedbacks: feedbacks }); } catch (error) { res.render('feedbacks_adm', { admin: req.session.user, listaFeedbacks: [] }); } });
app.get('/admin/feedback/:id', isAdmin, async (req, res) => { const feedbackId = req.params.id; const sql = `SELECT f.id, f.titulo, f.mensagem, f.status, DATE_FORMAT(f.data_envio, '%d/%m/%Y %H:%i') AS data_formatada, u.nome AS nome_cliente, u.email AS email_cliente, f.resposta_adm, f.data_resposta FROM feedbacks AS f LEFT JOIN usuarios AS u ON f.usuario_id = u.id WHERE f.id = ?;`; try { const [results] = await connection.execute(sql, [feedbackId]); if (results.length === 0) { return res.redirect('/admin/feedbacks'); } res.render('feedback_detalhe_adm', { admin: req.session.user, feedback: results[0] }); } catch (error) { res.redirect('/admin/feedbacks'); } });
app.post('/admin/feedback/atualizar-status/:id', isAdmin, async (req, res) => { const feedbackId = req.params.id; const { status } = req.body; const sql = "UPDATE feedbacks SET status = ? WHERE id = ?"; try { await connection.execute(sql, [status, feedbackId]); res.redirect(`/admin/feedback/${feedbackId}`); } catch (error) { res.redirect('/admin/feedbacks'); } });
app.post('/admin/feedback/responder/:id', isAdmin, async (req, res) => { const feedbackId = req.params.id; const { resposta } = req.body; const sql = "UPDATE feedbacks SET resposta_adm = ?, data_resposta = NOW() WHERE id = ?"; try { await connection.execute(sql, [resposta, feedbackId]); await connection.execute("UPDATE feedbacks SET status = 'resolvido' WHERE id = ?", [feedbackId]); res.redirect(`/admin/feedback/${feedbackId}`); } catch (error) { console.error("Erro ao salvar resposta do ADM:", error); res.redirect(`/admin/feedback/${feedbackId}`); } });
app.get('/api/admin/dados-vendas/:clienteId', isAdmin, async (req, res) => { const clienteId = req.params.clienteId; const sql = `SELECT DATE_FORMAT(data_venda, '%d/%m/%Y') as dia, SUM(valor_venda) as total_vendido FROM dados_ecommerce WHERE usuario_id = ? GROUP BY dia ORDER BY data_venda ASC;`; try { const [results] = await connection.execute(sql, [clienteId]); const labels = results.map(item => item.dia); const data = results.map(item => item.total_vendido); res.json({ labels, data }); } catch (error) { res.status(500).json({ error: 'Erro interno' }); } });
app.get('/api/admin/produtos-mais-vendidos/:clienteId', isAdmin, async (req, res) => { const clienteId = req.params.clienteId; const sql = `SELECT produto_vendido, COUNT(produto_vendido) as quantidade FROM dados_ecommerce WHERE usuario_id = ? GROUP BY produto_vendido ORDER BY quantidade DESC;`; try { const [results] = await connection.execute(sql, [clienteId]); const labels = results.map(item => item.produto_vendido); const data = results.map(item => item.quantidade); res.json({ labels, data }); } catch (error) { res.status(500).json({ error: 'Erro interno' }); } });
app.get('/logout', (req, res) => { req.session.destroy(err => { if (err) { return res.redirect('/'); } res.clearCookie('connect.sid'); res.redirect('/login'); }); });
app.listen(PORT, () => { console.log(`Servidor ByDash rodando em http://localhost:${PORT}`); });